# Agent Room: Phase 1 (sab ek Vercel dashboard me)

## Features
- **Leads:** local businesses (OpenStreetMap, free) + optional Reddit -> AI score 1-10 (hot/warm/cold), filter, search, CSV, status/phone, pitch + 3 follow-ups, "Send via WhatsApp" (wa.me, aap khud Send dabate ho), "Free audit PDF".
- **Content:** "Write article" (SEO, meta, FAQ schema, image), WordPress auto-post (bots), Reel/Short/Ad script, **Competitor spy** (gaps + better outline), **Course** (syllabus, lesson scripts, workbooks).
- **Video Studio:** script -> scenes -> AI images -> free Microsoft voice -> 9:16 video (browser me record hota hai).
- **B2B audit:** prospect ki website ka on-page audit + proposal PDF.
- **Freemium:** sign-up par 10 free credits (har tool ki cost alag), kaam fail ho to credits wapas.

## Login kaise kaam karta hai (ADMIN_KEY hata diya)
- **Open mode (default):** `SUPABASE_ANON_KEY` khali = koi login nahi. **Jiske paas link hai wo sab use kar sakta hai** (aapka AI quota, leads, WordPress). Sirf testing ke liye.
- **Sign-in mode:** `SUPABASE_ANON_KEY` + `ADMIN_EMAILS` daalo. Email + password se login; aapki email = owner (sab kuch, free); baaki users sirf tools (credits se), leads nahi dikhte.
  Supabase -> Authentication -> Providers -> Email: "Confirm email" ON rakho (free credits ka misuse kam hota hai).
  `CRON_SECRET` bhi daalo, warna roz ka auto-run band rehta hai.

## AI (OmniRoute)
`OMNIROUTE_BASE_URL` = aapke OmniRoute ka public `https://.../v1` (localhost Vercel se nahi dikhta), `OMNIROUTE_API_KEY` = uske API Keys page ki gateway key, `OMNIROUTE_MODEL` = model/combo ka naam (ya `auto`).
Free providers ki limits jaldi lag sakti hain; fail hone par OmniRoute ke fallback combos use karo.

## Zaroori baatein
- Video browser me banta hai: utni der lagti hai jitni video ki length, screen on + tab khula rakho. Chrome/Android aksar WebM deta hai.
- Microsoft voice unofficial hai; 403 aaye to `EDGE_TTS_CHROMIUM_VERSION` set karo.
- WhatsApp: har message aap khud bhejte ho; phir bhi unsolicited message report ho to ban ho sakta hai. Opt-out line + kam volume.
- OpenStreetMap: data "© OpenStreetMap contributors"; coverage shehar ke hisaab se alag, chhoti dukaano ka phone aksar missing. `OSM_USER_AGENT` me email daalo.
- Competitor spy / audit sirf public pages padhte hain, robots.txt maante hain. Audit PDF me sirf Latin text (Hindi "?" ban jata hai).
- Reddit ab optional hai (approval chahiye). Google Places hata diya (terms).
- WordPress FAQ schema (script tag) tabhi bachta hai jab WP user Administrator ho.

## Setup
1. Supabase SQL Editor me `supabase/schema.sql` run karo (dobara chalana safe).
2. Vercel Environment Variables: `.env.example` dekho. Minimum: SUPABASE_URL, SUPABASE_SERVICE_KEY, OMNIROUTE_BASE_URL (+KEY), BUSINESS_CONTEXT, OSM_USER_AGENT.
3. Redeploy. Pehle Write article, phir Leads (gyms + shehar), phir Video Studio test karo.
