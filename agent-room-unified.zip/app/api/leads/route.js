import { db } from '@/lib/db';
import { guard } from '@/lib/session';
export const dynamic = 'force-dynamic';
const H = { 'Cache-Control': 'no-store' };
const EDITABLE = ['phone', 'status', 'notes'];
export async function GET(req) {
  { const { deny } = await guard(req, { owner: true }); if (deny) return deny; }
  const { data, error } = await db().from('leads').select('*').order('id', { ascending: false }).limit(500);
  if (error) return Response.json({ error: error.message }, { status: 500, headers: H });
  return Response.json({ leads: data || [] }, { headers: H });
}
export async function PATCH(req) {
  { const { deny } = await guard(req, { owner: true }); if (deny) return deny; }
  const { id, fields = {} } = await req.json();
  const update = Object.fromEntries(Object.entries(fields).filter(([k]) => EDITABLE.includes(k)));
  if (!id || !Object.keys(update).length) return Response.json({ error: 'Nothing to update' }, { status: 400 });
  const { error } = await db().from('leads').update(update).eq('id', id);
  if (error) return Response.json({ error: error.message }, { status: 500 });
  return Response.json({ ok: true });
}
