import { authEnabled, getUser } from '@/lib/session';
import { balance } from '@/lib/credits';
import { cost } from '@/lib/credits';
import { provider } from '@/lib/llm';
import { redditReady } from '@/lib/reddit';
export const dynamic = 'force-dynamic';
export async function GET(req) {
  const user = await getUser(req);
  if (!user) return Response.json({ error: 'Please sign in', authEnabled: authEnabled() }, { status: 401, headers: { 'Cache-Control': 'no-store' } });
  return Response.json({
    email: user.email, role: user.role, open: !!user.open, authEnabled: authEnabled(), credits: await balance(user),
    costs: Object.fromEntries(['article', 'script', 'video', 'spy', 'course', 'audit'].map((a) => [a, cost(a)])),
    config: { provider: provider(), leadsReady: redditReady(), countryCode: process.env.DEFAULT_COUNTRY_CODE || '91' },
  }, { headers: { 'Cache-Control': 'no-store' } });
}
