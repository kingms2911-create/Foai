import { db } from '@/lib/db';
import { guard } from '@/lib/session';
export const dynamic = 'force-dynamic';
const ALLOWED = ['auto_publish', 'daily_limit', 'lead_queries', 'auto_leads'];
export async function POST(req) {
  { const { deny } = await guard(req, { owner: true }); if (deny) return deny; }
  const body = await req.json();
  const rows = Object.entries(body).filter(([k]) => ALLOWED.includes(k)).map(([key, value]) => ({ key, value: String(value) }));
  const { error } = await db().from('settings').upsert(rows);
  if (error) return Response.json({ error: error.message }, { status: 500 });
  return Response.json({ ok: true });
}
