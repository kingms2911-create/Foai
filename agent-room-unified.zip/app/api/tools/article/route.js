import { paid, stepped } from '@/lib/tools';
import { planArticle, writeSection, pollinationsUrl } from '@/lib/articleSteps';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;
// step "plan" charges credits and returns a ticket; step "section" (repeated) needs that ticket.
export async function POST(req) {
  const peek = await req.clone().json().catch(() => ({}));
  if (peek.step === 'section') {
    return stepped(req, 'article', async (b) => {
      const r = await writeSection({ seo: b.seo, extra: b.extra, index: Number(b.index), parts: b.parts || [] });
      return { ...r, imageUrl: r.done ? pollinationsUrl(b.seo.image_prompt || b.seo.title) : undefined };
    });
  }
  return paid(req, 'article', async (b) => {
    const topic = String(b.topic || '').trim();
    if (topic.length < 3) throw new Error('Write a topic first');
    return { seo: await planArticle({ topic: { title: topic, keyword: topic }, extra: b.extra }) };
  });
}
