import { paid, stepped } from '@/lib/tools';
import { syllabus, lessonScript, workbook } from '@/lib/course';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;
// step "syllabus" charges credits and returns a ticket; "lesson" / "workbook" steps need it.
export async function POST(req) {
  const peek = await req.clone().json().catch(() => ({}));
  if (peek.step === 'lesson' || peek.step === 'workbook') {
    return stepped(req, 'course', async (b) => ({ text: await (b.step === 'lesson' ? lessonScript(b) : workbook(b)) }));
  }
  return paid(req, 'course', async (b) => {
    if (!b.topic || !b.audience) throw new Error('Add the course topic and who it is for');
    return { syllabus: await syllabus({ topic: b.topic, audience: b.audience, level: b.level, modules: b.modules, lessons: b.lessons }) };
  });
}
