import { paid } from '@/lib/tools';
import { analyzeCompetitors, spyNotes } from '@/lib/spy';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;
export const POST = (req) => paid(req, 'spy', async (b) => {
  const urls = (Array.isArray(b.urls) ? b.urls : String(b.urls || '').split(/\s+/)).map((u) => u.trim()).filter(Boolean);
  if (!b.keyword || !urls.length) throw new Error('Add a keyword and at least one competitor page URL');
  const analysis = await analyzeCompetitors(String(b.keyword), urls);
  return { analysis, notes: spyNotes(analysis) };
});
