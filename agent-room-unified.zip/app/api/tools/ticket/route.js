import { paid } from '@/lib/tools';
export const dynamic = 'force-dynamic';
// Charges once for a video session; the returned ticket unlocks image + voice calls for 30 minutes.
export const POST = (req) => paid(req, 'video', async () => ({}));
