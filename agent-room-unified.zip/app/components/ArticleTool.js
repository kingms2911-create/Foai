'use client';
import { useState } from 'react';
import { api, downloadBlob, price, sleep } from '@/lib/clientApi';

const doc = (seo, html, imageUrl) => `<!doctype html><html><head><meta charset="utf-8"><title>${seo.title.replace(/</g, '&lt;')}</title><meta name="description" content="${(seo.meta_description || '').replace(/"/g, '&quot;')}"></head><body style="font-family:sans-serif;max-width:720px;margin:auto;padding:12px;line-height:1.6">${imageUrl ? `<img src="${imageUrl}" alt="" style="max-width:100%">` : ''}<h1>${seo.title.replace(/</g, '&lt;')}</h1>${html}</body></html>`;

export default function ArticleTool({ me, onUsed, notes }) {
  const [topic, setTopic] = useState('');
  const [useNotes, setUseNotes] = useState(false);
  const [status, setStatus] = useState('');
  const [err, setErr] = useState('');
  const [out, setOut] = useState(null);

  const go = async () => {
    setErr(''); setOut(null);
    try {
      const extra = useNotes && notes ? notes : undefined;
      setStatus('Planning the article…');
      const p = await api('/api/tools/article', { step: 'plan', topic, extra });
      onUsed();
      const total = p.seo.outline.length + 1;
      let parts = [], r;
      for (let i = 0; i < total; i++) {
        setStatus(`Writing part ${i + 1} of ${total}…`);
        r = await api('/api/tools/article', { step: 'section', ticket: p.ticket, seo: p.seo, extra, index: i, parts });
        parts = r.parts;
        if (i < total - 1) await sleep(me?.config?.provider === 'gemini' ? 4000 : 500);
      }
      setOut({ seo: p.seo, html: r.html, imageUrl: r.imageUrl });
    } catch (e) { setErr(e.message); }
    setStatus(''); onUsed();
  };

  return (
    <div>
      <label>Article topic or keyword</label>
      <input type="text" value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="e.g. best SIP plans for beginners" />
      {notes && <label style={{ fontWeight: 400 }}><input type="checkbox" checked={useNotes} onChange={(e) => setUseNotes(e.target.checked)} style={{ width: 'auto' }} /> Use my competitor analysis to beat existing articles</label>}
      <p><button className="btn" onClick={go} disabled={!!status || topic.trim().length < 3}>{`✍️ Write article${price(me, 'article')}`}</button></p>
      {status && <p className="sub">{status}</p>}
      {err && <p className="err">{err}</p>}
      {out && (
        <div>
          <div className="card"><b>{out.seo.title}</b><br /><small>Meta ({out.seo.meta_description.length}/160): {out.seo.meta_description}</small></div>
          {out.imageUrl && <img src={out.imageUrl} alt="" style={{ width: '100%', borderRadius: 10, marginBottom: 8 }} />}
          <iframe title="Article preview" sandbox="" srcDoc={doc(out.seo, out.html, '')} style={{ width: '100%', height: 420, border: '1px solid var(--line)', borderRadius: 10, background: '#fff' }} />
          <p>
            <button className="btn small" onClick={() => downloadBlob(new Blob([doc(out.seo, out.html, out.imageUrl)], { type: 'text/html' }), `${out.seo.slug || 'article'}.html`)}>⬇️ Download HTML</button>{' '}
            <button className="btn small ghost" onClick={() => navigator.clipboard?.writeText(out.html)}>Copy HTML</button>
          </p>
          <p className="sub">Includes FAQ schema. Paste the HTML into WordPress (Custom HTML block) or use the auto-post tab to publish directly.</p>
        </div>
      )}
    </div>
  );
}
