'use client';
import { useState } from 'react';
import { api, base64ToBlob, downloadBlob, price } from '@/lib/clientApi';

const COLOR = { good: '#15803d', warn: '#b45309', bad: '#b91c1c' };
const LABEL = { good: 'Good', warn: 'Improve', bad: 'Fix' };

export default function AuditTab({ me, onUsed }) {
  const [company, setCompany] = useState('');
  const [url, setUrl] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [res, setRes] = useState(null);

  const go = async () => {
    setBusy(true); setErr(''); setRes(null);
    try { setRes(await api('/api/tools/audit', { company, url })); } catch (e) { setErr(e.message); }
    setBusy(false); onUsed();
  };
  return (
    <div>
      <label>Prospect company</label><input type="text" value={company} onChange={(e) => setCompany(e.target.value)} />
      <label>Their website</label><input type="text" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://example.com" />
      <p><button className="btn" onClick={go} disabled={busy || company.trim().length < 2 || url.trim().length < 4}>{busy ? 'Auditing…' : `📄 Build audit + proposal PDF${price(me, 'audit')}`}</button></p>
      <p className="sub">Checks the public homepage only (title, meta, headings, mobile, schema, images) and writes a short proposal. Use it as a free-audit hook in outreach.</p>
      {err && <p className="err">{err}</p>}
      {res && (
        <div>
          <div className="stats"><div className="stat"><b>{res.audit.score}/100</b><span>On-page score</span></div></div>
          {res.audit.checks.map((c) => <div className="card" key={c.name}><b>{c.name}</b> <span style={{ color: COLOR[c.status], fontWeight: 700 }}>{LABEL[c.status]}</span><br /><small>{c.detail}</small></div>)}
          <p><button className="btn" onClick={() => downloadBlob(base64ToBlob(res.pdf, 'application/pdf'), `audit-${company.replace(/\W+/g, '-').toLowerCase()}.pdf`)}>⬇️ Download PDF</button></p>
        </div>
      )}
    </div>
  );
}
