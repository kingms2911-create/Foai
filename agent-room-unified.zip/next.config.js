/** @type {import('next').NextConfig} */
module.exports = { experimental: { serverComponentsExternalPackages: ['ws'] } };
