-- Safe to run again and again (idempotent). Run in Supabase -> SQL Editor.
create table if not exists tasks (
  id bigserial primary key, created_at timestamptz default now(), updated_at timestamptz default now(),
  type text not null, niche text, status text default 'pending', attempts int default 0,
  payload jsonb default '{}', result jsonb, error text);
create table if not exists board (
  id bigserial primary key, created_at timestamptz default now(),
  agent text, role text, kind text, content text, task_id bigint);
create table if not exists leads (
  id bigserial primary key, created_at timestamptz default now(),
  name text, address text, phone text, website text, query text, unique (name, address));
alter table leads add column if not exists source text default 'places';
alter table leads add column if not exists username text;
alter table leads add column if not exists keyword text;
alter table leads add column if not exists subreddit text;
alter table leads add column if not exists title text;
alter table leads add column if not exists url text;
alter table leads add column if not exists intent_summary text;
alter table leads add column if not exists score int;
alter table leads add column if not exists category text;
alter table leads add column if not exists status text default 'new';
alter table leads add column if not exists outreach jsonb;
alter table leads add column if not exists notes text;
alter table leads add column if not exists source_id text;
alter table leads add column if not exists city text;
create table if not exists seen (id text primary key, created_at timestamptz default now());
create table if not exists settings (key text primary key, value text);
insert into settings values ('auto_publish','false'),('daily_limit','3'),('lead_queries',''),('auto_leads','true') on conflict do nothing;
alter table tasks enable row level security;
alter table board enable row level security;
alter table leads enable row level security;
alter table seen enable row level security;
alter table settings enable row level security;

-- ---------- Freemium credits (safe to re-run) ----------
create table if not exists py_credits (
  user_id uuid primary key, email text, credits int not null default 0, created_at timestamptz default now());
create table if not exists py_credit_log (
  id bigserial primary key, created_at timestamptz default now(), user_id uuid, delta int, reason text);
alter table py_credits enable row level security;
alter table py_credit_log enable row level security;

create or replace function spend_credits(p_user uuid, p_amount int, p_reason text) returns int
language plpgsql security definer as $$
declare new_bal int;
begin
  update py_credits set credits = credits - p_amount where user_id = p_user and credits >= p_amount returning credits into new_bal;
  if new_bal is null then return -1; end if;
  insert into py_credit_log(user_id, delta, reason) values (p_user, -p_amount, p_reason);
  return new_bal;
end $$;

create or replace function add_credits(p_user uuid, p_amount int, p_reason text) returns int
language plpgsql security definer as $$
declare new_bal int;
begin
  update py_credits set credits = credits + p_amount where user_id = p_user returning credits into new_bal;
  insert into py_credit_log(user_id, delta, reason) values (p_user, p_amount, p_reason);
  return new_bal;
end $$;

revoke execute on function spend_credits(uuid, int, text) from public, anon, authenticated;
revoke execute on function add_credits(uuid, int, text) from public, anon, authenticated;
grant execute on function spend_credits(uuid, int, text) to service_role;
grant execute on function add_credits(uuid, int, text) to service_role;
